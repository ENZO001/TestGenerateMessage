package com.ctbcbank.pcms.form;

import com.ctbcbank.pcms.htg.BaseForm;

public class Form067050 extends BaseForm {

	private static final long serialVersionUID = 1L;

	private String cust_no;
	private String optn;
	private String cust_id_no;
	private String id_type;

	public String getCust_no() {
		return cust_no;
	}

	public void setCust_no(String cust_no) {
		this.cust_no = cust_no;
	}

	public String getOptn() {
		return optn;
	}

	public void setOptn(String optn) {
		this.optn = optn;
	}

	public String getCust_id_no() {
		return cust_id_no;
	}

	public void setCust_id_no(String cust_id_no) {
		this.cust_id_no = cust_id_no;
	}

	public String getId_type() {
		return id_type;
	}

	public void setId_type(String id_type) {
		this.id_type = id_type;
	}

}
