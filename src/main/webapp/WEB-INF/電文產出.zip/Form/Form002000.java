package com.ctbcbank.pcms.form;

import com.ctbcbank.pcms.htg.BaseForm;

public class Form002000 extends BaseForm {

	private static final long serialVersionUID = 1L;

	private String sacctno;
	private String custno;
	private String custIdNo;
	private String idtype;
	private String accname;
	private String address1;
	private String address2;
	private String field1;
	private String address3;
	private String currenc3;
	private String address4;
	private String postcode;
	private String accttype;
	private String intcat;
	private String legalent;
	private String space1;
	private String intpaymethod;
	private String space2;
	private String tfracctno;
	private String chexpro;
	private String langcode;
	private String freq;
	private String space3;
	private String stdaind;
	private String mailind;
	private String notind;
	private String notcust;
	private String vainrate;
	private String space4;
	private String intfreq;
	private String cycle;
	private String day;
	private String agentcd;
	private String invtype;
	private String district;
	private String segmentCode;
	private String space5;
	private String bussinessType;
	private String space6;
	private String groupind;
	private String facno;
	private String applid;
	private String space7;
	private String visaflag;
	private String visecode;
	private String vicrlim;
	private String space8;
	private String termlength;
	private String frequencyCode;
	private String termval;
	private String space9;
	private String tigrid;
	private String curidori;
	private String custrisk;
	private String arcbrisk;
	private String secind;
	private String timeband;
	private String bankid;
	private String space10;
	private String opendate;
	private String copies;
	private String filler5;
	private String acexind;
	private String matrate;
	private String filler6;
	private String certificateno;
	private String rateType;
	private String stampTaxFlag;
	private String rateincr;
	private String referral;
	private String space11;
	private String glcc;
	private String securityno;
	private String empno;
	private String omnibus;
	private String promcode;
	private String space12;
	private String investcode;
	private String omnibusacct;
	private String tlrFlag;
	private String rtLimit;
	private String investtype;
	private String trustProdMemo; // 信託產品註記
	private String publishNo; // 發行批號
	private String billsNo; // 首買票券商代號
	private String portfolioNo; // 投資組合代碼
	private String openPurpose; // 開戶目的
	private String ncdRegistered; // NCD記名註記
	private String personFlag; // 個/法人註記
	private String autoRoll; // 定存到期處理方式
	private String mnthyEstiDepCnt; // 每月預計存入次數
	private String mnthyEstiDepAmtTwd; // 每月預計存入等值新臺幣金額
	private String mnthyEstiDepAmtUsd; // 每月預計存入等值美元金額
	private String mnthyEstiWdlCnt; // 每月預計提領次數
	private String mnthyEstiWdlAmtTwd; // 每月預計提領等值新臺幣金額
	private String mnthyEstiWdlAmtUsd; // 每月預計提領等值美元金額
	private String iUseFlag; // 本人使用

	public String getSacctno() {
		return sacctno;
	}

	public void setSacctno(String sacctno) {
		this.sacctno = sacctno;
	}

	public String getCustno() {
		return custno;
	}

	public void setCustno(String custno) {
		this.custno = custno;
	}

	public String getCustIdNo() {
		return custIdNo;
	}

	public void setCustIdNo(String custIdNo) {
		this.custIdNo = custIdNo;
	}

	public String getIdtype() {
		return idtype;
	}

	public void setIdtype(String idtype) {
		this.idtype = idtype;
	}

	public String getAccname() {
		return accname;
	}

	public void setAccname(String accname) {
		this.accname = accname;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getField1() {
		return field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getCurrenc3() {
		return currenc3;
	}

	public void setCurrenc3(String currenc3) {
		this.currenc3 = currenc3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getAccttype() {
		return accttype;
	}

	public void setAccttype(String accttype) {
		this.accttype = accttype;
	}

	public String getIntcat() {
		return intcat;
	}

	public void setIntcat(String intcat) {
		this.intcat = intcat;
	}

	public String getLegalent() {
		return legalent;
	}

	public void setLegalent(String legalent) {
		this.legalent = legalent;
	}

	public String getSpace1() {
		return space1;
	}

	public void setSpace1(String space1) {
		this.space1 = space1;
	}

	public String getIntpaymethod() {
		return intpaymethod;
	}

	public void setIntpaymethod(String intpaymethod) {
		this.intpaymethod = intpaymethod;
	}

	public String getSpace2() {
		return space2;
	}

	public void setSpace2(String space2) {
		this.space2 = space2;
	}

	public String getTfracctno() {
		return tfracctno;
	}

	public void setTfracctno(String tfracctno) {
		this.tfracctno = tfracctno;
	}

	public String getChexpro() {
		return chexpro;
	}

	public void setChexpro(String chexpro) {
		this.chexpro = chexpro;
	}

	public String getLangcode() {
		return langcode;
	}

	public void setLangcode(String langcode) {
		this.langcode = langcode;
	}

	public String getFreq() {
		return freq;
	}

	public void setFreq(String freq) {
		this.freq = freq;
	}

	public String getSpace3() {
		return space3;
	}

	public void setSpace3(String space3) {
		this.space3 = space3;
	}

	public String getStdaind() {
		return stdaind;
	}

	public void setStdaind(String stdaind) {
		this.stdaind = stdaind;
	}

	public String getMailind() {
		return mailind;
	}

	public void setMailind(String mailind) {
		this.mailind = mailind;
	}

	public String getNotind() {
		return notind;
	}

	public void setNotind(String notind) {
		this.notind = notind;
	}

	public String getNotcust() {
		return notcust;
	}

	public void setNotcust(String notcust) {
		this.notcust = notcust;
	}

	public String getVainrate() {
		return vainrate;
	}

	public void setVainrate(String vainrate) {
		this.vainrate = vainrate;
	}

	public String getSpace4() {
		return space4;
	}

	public void setSpace4(String space4) {
		this.space4 = space4;
	}

	public String getIntfreq() {
		return intfreq;
	}

	public void setIntfreq(String intfreq) {
		this.intfreq = intfreq;
	}

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getAgentcd() {
		return agentcd;
	}

	public void setAgentcd(String agentcd) {
		this.agentcd = agentcd;
	}

	public String getInvtype() {
		return invtype;
	}

	public void setInvtype(String invtype) {
		this.invtype = invtype;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getSegmentCode() {
		return segmentCode;
	}

	public void setSegmentCode(String segmentCode) {
		this.segmentCode = segmentCode;
	}

	public String getSpace5() {
		return space5;
	}

	public void setSpace5(String space5) {
		this.space5 = space5;
	}

	public String getBussinessType() {
		return bussinessType;
	}

	public void setBussinessType(String bussinessType) {
		this.bussinessType = bussinessType;
	}

	public String getSpace6() {
		return space6;
	}

	public void setSpace6(String space6) {
		this.space6 = space6;
	}

	public String getGroupind() {
		return groupind;
	}

	public void setGroupind(String groupind) {
		this.groupind = groupind;
	}

	public String getFacno() {
		return facno;
	}

	public void setFacno(String facno) {
		this.facno = facno;
	}

	public String getApplid() {
		return applid;
	}

	public void setApplid(String applid) {
		this.applid = applid;
	}

	public String getSpace7() {
		return space7;
	}

	public void setSpace7(String space7) {
		this.space7 = space7;
	}

	public String getVisaflag() {
		return visaflag;
	}

	public void setVisaflag(String visaflag) {
		this.visaflag = visaflag;
	}

	public String getVisecode() {
		return visecode;
	}

	public void setVisecode(String visecode) {
		this.visecode = visecode;
	}

	public String getVicrlim() {
		return vicrlim;
	}

	public void setVicrlim(String vicrlim) {
		this.vicrlim = vicrlim;
	}

	public String getSpace8() {
		return space8;
	}

	public void setSpace8(String space8) {
		this.space8 = space8;
	}

	public String getTermlength() {
		return termlength;
	}

	public void setTermlength(String termlength) {
		this.termlength = termlength;
	}

	public String getFrequencyCode() {
		return frequencyCode;
	}

	public void setFrequencyCode(String frequencyCode) {
		this.frequencyCode = frequencyCode;
	}

	public String getTermval() {
		return termval;
	}

	public void setTermval(String termval) {
		this.termval = termval;
	}

	public String getSpace9() {
		return space9;
	}

	public void setSpace9(String space9) {
		this.space9 = space9;
	}

	public String getTigrid() {
		return tigrid;
	}

	public void setTigrid(String tigrid) {
		this.tigrid = tigrid;
	}

	public String getCuridori() {
		return curidori;
	}

	public void setCuridori(String curidori) {
		this.curidori = curidori;
	}

	public String getCustrisk() {
		return custrisk;
	}

	public void setCustrisk(String custrisk) {
		this.custrisk = custrisk;
	}

	public String getArcbrisk() {
		return arcbrisk;
	}

	public void setArcbrisk(String arcbrisk) {
		this.arcbrisk = arcbrisk;
	}

	public String getSecind() {
		return secind;
	}

	public void setSecind(String secind) {
		this.secind = secind;
	}

	public String getTimeband() {
		return timeband;
	}

	public void setTimeband(String timeband) {
		this.timeband = timeband;
	}

	public String getBankid() {
		return bankid;
	}

	public void setBankid(String bankid) {
		this.bankid = bankid;
	}

	public String getSpace10() {
		return space10;
	}

	public void setSpace10(String space10) {
		this.space10 = space10;
	}

	public String getOpendate() {
		return opendate;
	}

	public void setOpendate(String opendate) {
		this.opendate = opendate;
	}

	public String getCopies() {
		return copies;
	}

	public void setCopies(String copies) {
		this.copies = copies;
	}

	public String getFiller5() {
		return filler5;
	}

	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}

	public String getAcexind() {
		return acexind;
	}

	public void setAcexind(String acexind) {
		this.acexind = acexind;
	}

	public String getMatrate() {
		return matrate;
	}

	public void setMatrate(String matrate) {
		this.matrate = matrate;
	}

	public String getFiller6() {
		return filler6;
	}

	public void setFiller6(String filler6) {
		this.filler6 = filler6;
	}

	public String getCertificateno() {
		return certificateno;
	}

	public void setCertificateno(String certificateno) {
		this.certificateno = certificateno;
	}

	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public String getStampTaxFlag() {
		return stampTaxFlag;
	}

	public void setStampTaxFlag(String stampTaxFlag) {
		this.stampTaxFlag = stampTaxFlag;
	}

	public String getRateincr() {
		return rateincr;
	}

	public void setRateincr(String rateincr) {
		this.rateincr = rateincr;
	}

	public String getReferral() {
		return referral;
	}

	public void setReferral(String referral) {
		this.referral = referral;
	}

	public String getSpace11() {
		return space11;
	}

	public void setSpace11(String space11) {
		this.space11 = space11;
	}

	public String getGlcc() {
		return glcc;
	}

	public void setGlcc(String glcc) {
		this.glcc = glcc;
	}

	public String getSecurityno() {
		return securityno;
	}

	public void setSecurityno(String securityno) {
		this.securityno = securityno;
	}

	public String getEmpno() {
		return empno;
	}

	public void setEmpno(String empno) {
		this.empno = empno;
	}

	public String getOmnibus() {
		return omnibus;
	}

	public void setOmnibus(String omnibus) {
		this.omnibus = omnibus;
	}

	public String getPromcode() {
		return promcode;
	}

	public void setPromcode(String promcode) {
		this.promcode = promcode;
	}

	public String getSpace12() {
		return space12;
	}

	public void setSpace12(String space12) {
		this.space12 = space12;
	}

	public String getInvestcode() {
		return investcode;
	}

	public void setInvestcode(String investcode) {
		this.investcode = investcode;
	}

	public String getOmnibusacct() {
		return omnibusacct;
	}

	public void setOmnibusacct(String omnibusacct) {
		this.omnibusacct = omnibusacct;
	}

	public String getTlrFlag() {
		return tlrFlag;
	}

	public void setTlrFlag(String tlrFlag) {
		this.tlrFlag = tlrFlag;
	}

	public String getRtLimit() {
		return rtLimit;
	}

	public void setRtLimit(String rtLimit) {
		this.rtLimit = rtLimit;
	}

	public String getInvesttype() {
		return investtype;
	}

	public void setInvesttype(String investtype) {
		this.investtype = investtype;
	}

	public String getTrustProdMemo() {
		return trustProdMemo;
	}

	public void setTrustProdMemo(String trustProdMemo) {
		this.trustProdMemo = trustProdMemo;
	}

	public String getPublishNo() {
		return publishNo;
	}

	public void setPublishNo(String publishNo) {
		this.publishNo = publishNo;
	}

	public String getBillsNo() {
		return billsNo;
	}

	public void setBillsNo(String billsNo) {
		this.billsNo = billsNo;
	}

	public String getPortfolioNo() {
		return portfolioNo;
	}

	public void setPortfolioNo(String portfolioNo) {
		this.portfolioNo = portfolioNo;
	}

	public String getOpenPurpose() {
		return openPurpose;
	}

	public void setOpenPurpose(String openPurpose) {
		this.openPurpose = openPurpose;
	}

	public String getNcdRegistered() {
		return ncdRegistered;
	}

	public void setNcdRegistered(String ncdRegistered) {
		this.ncdRegistered = ncdRegistered;
	}

	public String getPersonFlag() {
		return personFlag;
	}

	public void setPersonFlag(String personFlag) {
		this.personFlag = personFlag;
	}

	public String getAutoRoll() {
		return autoRoll;
	}

	public void setAutoRoll(String autoRoll) {
		this.autoRoll = autoRoll;
	}

	public String getMnthyEstiDepCnt() {
		return mnthyEstiDepCnt;
	}

	public void setMnthyEstiDepCnt(String mnthyEstiDepCnt) {
		this.mnthyEstiDepCnt = mnthyEstiDepCnt;
	}

	public String getMnthyEstiDepAmtTwd() {
		return mnthyEstiDepAmtTwd;
	}

	public void setMnthyEstiDepAmtTwd(String mnthyEstiDepAmtTwd) {
		this.mnthyEstiDepAmtTwd = mnthyEstiDepAmtTwd;
	}

	public String getMnthyEstiDepAmtUsd() {
		return mnthyEstiDepAmtUsd;
	}

	public void setMnthyEstiDepAmtUsd(String mnthyEstiDepAmtUsd) {
		this.mnthyEstiDepAmtUsd = mnthyEstiDepAmtUsd;
	}

	public String getMnthyEstiWdlCnt() {
		return mnthyEstiWdlCnt;
	}

	public void setMnthyEstiWdlCnt(String mnthyEstiWdlCnt) {
		this.mnthyEstiWdlCnt = mnthyEstiWdlCnt;
	}

	public String getMnthyEstiWdlAmtTwd() {
		return mnthyEstiWdlAmtTwd;
	}

	public void setMnthyEstiWdlAmtTwd(String mnthyEstiWdlAmtTwd) {
		this.mnthyEstiWdlAmtTwd = mnthyEstiWdlAmtTwd;
	}

	public String getMnthyEstiWdlAmtUsd() {
		return mnthyEstiWdlAmtUsd;
	}

	public void setMnthyEstiWdlAmtUsd(String mnthyEstiWdlAmtUsd) {
		this.mnthyEstiWdlAmtUsd = mnthyEstiWdlAmtUsd;
	}

	public String getiUseFlag() {
		return iUseFlag;
	}

	public void setiUseFlag(String iUseFlag) {
		this.iUseFlag = iUseFlag;
	}

}
