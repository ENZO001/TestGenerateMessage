package com.ctbcbank.pcms.form;

import com.ctbcbank.pcms.htg.BaseForm;

public class Form067102 extends BaseForm {

	private static final long serialVersionUID = 1L;

	private String cifNo;
	private String custName;
	private String regCmpyNo;
	private String name01;
	private String titleCode01;
	private String titleDesc01;
	private String name02;
	private String titleCode02;
	private String titleDesc03;
	private String tradLicNo;
	private String regBisNo;
	private String custIdNo;
	private String idType;
	private String respCustId;
	private String respIdType;
	private String respName;
	private String mailInd;
	private String incomeAmt;
	private String financGoods1; // 投資經驗與知識欄位(無)
	private String financGoods2; // 投資經驗與知識欄位(基金)
	private String financGoods3; // 投資經驗與知識欄位(保險)
	private String financGoods4; // 投資經驗與知識欄位(定存)
	private String financGoods5; // 投資經驗與知識欄位(外幣)
	private String financGoods6; // 投資經驗與知識欄位(信託)
	private String financGoods7; // 投資經驗與知識欄位(貸款)
	private String financGoods8; // 投資經驗與知識欄位(信用卡)
	private String financGoods9; // 投資經驗與知識欄位(股票/期貨)
	private String financGoods10; // 投資經驗與知識欄位(連動債)
	private String financGoods11; // 投資經驗與知識欄位(房地產)
	private String financGoods12; // 投資經驗與知識欄位(海外投資)
	private String financGoods13; // 投資經驗與知識欄位(房貸)
	private String financGoods14; // 投資經驗與知識欄位(信貸)
	private String financGoods15; // 投資經驗與知識欄位(現金卡)
	private String financGoods16; // 投資經驗與知識欄位(企業貸款)
	private String financGoods17; // 投資經驗與知識欄位(其他)
	private String financGoods18;
	private String financGoods19;
	private String financGoods20;
	private String financGoods21;
	private String financGoods22;
	private String financGoods23;
	private String financGoods24;
	private String financGoods25;
	private String financGoods26;
	private String financGoods27;
	private String financGoods28;
	private String financGoods29;
	private String financGoods30;
	private String financGoods31;
	private String financGoods32;
	private String billType;
	private String billCycle;
	private String billDate;
	private String loanNotifyType;
	private String sbuBillDt;
	private String headOffice; // 總行統編
	private String bankslipNonmail; // 水單不寄送flag
	private String wdmsId;
	private String openAim; // 開戶目的
	private String waiveAdjCnt; // SB跨轉調整次數
	private String promCode;
	private String setStatus; // 設立狀態
	private String setStatusDate; // 設立狀態資料年月
	private String complxStructFlag; // 複雜股權結構(註記)
	private String nonRegisterFlag; // 無記名股份公司(註記)
	private String swiftCode; // 銀行總行swift-code
	private String smeCorpFlag; // 法人中小企業註記
	private String setPurpose; // OBU法人設立目的
	private String amlPriBusNation; // 主要之營業處所國別
	private String amlBusNationRisk; // 海外營業處所
	private String amlBusNationRisk1; // 營業處所位於高風險/制裁國別 1
	private String amlBusNationRisk2; // 營業處所位於高風險/制裁國別 2
	private String amlBusNationRisk3; // 營業處所位於高風險/制裁國別 3
	private String amlBusNationRisk4; // 營業處所位於高風險/制裁國別 4
	private String amlBusNationRisk5; // 營業處所位於高風險/制裁國別 5
	private String amlOversFor; // 僑外資/外商(Y/N)
	private String amlOversForNation; // 僑外資/外商之母公司註冊地國別

	public String getCifNo() {
		return cifNo;
	}

	public void setCifNo(String cifNo) {
		this.cifNo = cifNo;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getRegCmpyNo() {
		return regCmpyNo;
	}

	public void setRegCmpyNo(String regCmpyNo) {
		this.regCmpyNo = regCmpyNo;
	}

	public String getName01() {
		return name01;
	}

	public void setName01(String name01) {
		this.name01 = name01;
	}

	public String getTitleCode01() {
		return titleCode01;
	}

	public void setTitleCode01(String titleCode01) {
		this.titleCode01 = titleCode01;
	}

	public String getTitleDesc01() {
		return titleDesc01;
	}

	public void setTitleDesc01(String titleDesc01) {
		this.titleDesc01 = titleDesc01;
	}

	public String getName02() {
		return name02;
	}

	public void setName02(String name02) {
		this.name02 = name02;
	}

	public String getTitleCode02() {
		return titleCode02;
	}

	public void setTitleCode02(String titleCode02) {
		this.titleCode02 = titleCode02;
	}

	public String getTitleDesc03() {
		return titleDesc03;
	}

	public void setTitleDesc03(String titleDesc03) {
		this.titleDesc03 = titleDesc03;
	}

	public String getTradLicNo() {
		return tradLicNo;
	}

	public void setTradLicNo(String tradLicNo) {
		this.tradLicNo = tradLicNo;
	}

	public String getRegBisNo() {
		return regBisNo;
	}

	public void setRegBisNo(String regBisNo) {
		this.regBisNo = regBisNo;
	}

	public String getCustIdNo() {
		return custIdNo;
	}

	public void setCustIdNo(String custIdNo) {
		this.custIdNo = custIdNo;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getRespCustId() {
		return respCustId;
	}

	public void setRespCustId(String respCustId) {
		this.respCustId = respCustId;
	}

	public String getRespIdType() {
		return respIdType;
	}

	public void setRespIdType(String respIdType) {
		this.respIdType = respIdType;
	}

	public String getRespName() {
		return respName;
	}

	public void setRespName(String respName) {
		this.respName = respName;
	}

	public String getMailInd() {
		return mailInd;
	}

	public void setMailInd(String mailInd) {
		this.mailInd = mailInd;
	}

	public String getIncomeAmt() {
		return incomeAmt;
	}

	public void setIncomeAmt(String incomeAmt) {
		this.incomeAmt = incomeAmt;
	}

	public String getFinancGoods1() {
		return financGoods1;
	}

	public void setFinancGoods1(String financGoods1) {
		this.financGoods1 = financGoods1;
	}

	public String getFinancGoods2() {
		return financGoods2;
	}

	public void setFinancGoods2(String financGoods2) {
		this.financGoods2 = financGoods2;
	}

	public String getFinancGoods3() {
		return financGoods3;
	}

	public void setFinancGoods3(String financGoods3) {
		this.financGoods3 = financGoods3;
	}

	public String getFinancGoods4() {
		return financGoods4;
	}

	public void setFinancGoods4(String financGoods4) {
		this.financGoods4 = financGoods4;
	}

	public String getFinancGoods5() {
		return financGoods5;
	}

	public void setFinancGoods5(String financGoods5) {
		this.financGoods5 = financGoods5;
	}

	public String getFinancGoods6() {
		return financGoods6;
	}

	public void setFinancGoods6(String financGoods6) {
		this.financGoods6 = financGoods6;
	}

	public String getFinancGoods7() {
		return financGoods7;
	}

	public void setFinancGoods7(String financGoods7) {
		this.financGoods7 = financGoods7;
	}

	public String getFinancGoods8() {
		return financGoods8;
	}

	public void setFinancGoods8(String financGoods8) {
		this.financGoods8 = financGoods8;
	}

	public String getFinancGoods9() {
		return financGoods9;
	}

	public void setFinancGoods9(String financGoods9) {
		this.financGoods9 = financGoods9;
	}

	public String getFinancGoods10() {
		return financGoods10;
	}

	public void setFinancGoods10(String financGoods10) {
		this.financGoods10 = financGoods10;
	}

	public String getFinancGoods11() {
		return financGoods11;
	}

	public void setFinancGoods11(String financGoods11) {
		this.financGoods11 = financGoods11;
	}

	public String getFinancGoods12() {
		return financGoods12;
	}

	public void setFinancGoods12(String financGoods12) {
		this.financGoods12 = financGoods12;
	}

	public String getFinancGoods13() {
		return financGoods13;
	}

	public void setFinancGoods13(String financGoods13) {
		this.financGoods13 = financGoods13;
	}

	public String getFinancGoods14() {
		return financGoods14;
	}

	public void setFinancGoods14(String financGoods14) {
		this.financGoods14 = financGoods14;
	}

	public String getFinancGoods15() {
		return financGoods15;
	}

	public void setFinancGoods15(String financGoods15) {
		this.financGoods15 = financGoods15;
	}

	public String getFinancGoods16() {
		return financGoods16;
	}

	public void setFinancGoods16(String financGoods16) {
		this.financGoods16 = financGoods16;
	}

	public String getFinancGoods17() {
		return financGoods17;
	}

	public void setFinancGoods17(String financGoods17) {
		this.financGoods17 = financGoods17;
	}

	public String getFinancGoods18() {
		return financGoods18;
	}

	public void setFinancGoods18(String financGoods18) {
		this.financGoods18 = financGoods18;
	}

	public String getFinancGoods19() {
		return financGoods19;
	}

	public void setFinancGoods19(String financGoods19) {
		this.financGoods19 = financGoods19;
	}

	public String getFinancGoods20() {
		return financGoods20;
	}

	public void setFinancGoods20(String financGoods20) {
		this.financGoods20 = financGoods20;
	}

	public String getFinancGoods21() {
		return financGoods21;
	}

	public void setFinancGoods21(String financGoods21) {
		this.financGoods21 = financGoods21;
	}

	public String getFinancGoods22() {
		return financGoods22;
	}

	public void setFinancGoods22(String financGoods22) {
		this.financGoods22 = financGoods22;
	}

	public String getFinancGoods23() {
		return financGoods23;
	}

	public void setFinancGoods23(String financGoods23) {
		this.financGoods23 = financGoods23;
	}

	public String getFinancGoods24() {
		return financGoods24;
	}

	public void setFinancGoods24(String financGoods24) {
		this.financGoods24 = financGoods24;
	}

	public String getFinancGoods25() {
		return financGoods25;
	}

	public void setFinancGoods25(String financGoods25) {
		this.financGoods25 = financGoods25;
	}

	public String getFinancGoods26() {
		return financGoods26;
	}

	public void setFinancGoods26(String financGoods26) {
		this.financGoods26 = financGoods26;
	}

	public String getFinancGoods27() {
		return financGoods27;
	}

	public void setFinancGoods27(String financGoods27) {
		this.financGoods27 = financGoods27;
	}

	public String getFinancGoods28() {
		return financGoods28;
	}

	public void setFinancGoods28(String financGoods28) {
		this.financGoods28 = financGoods28;
	}

	public String getFinancGoods29() {
		return financGoods29;
	}

	public void setFinancGoods29(String financGoods29) {
		this.financGoods29 = financGoods29;
	}

	public String getFinancGoods30() {
		return financGoods30;
	}

	public void setFinancGoods30(String financGoods30) {
		this.financGoods30 = financGoods30;
	}

	public String getFinancGoods31() {
		return financGoods31;
	}

	public void setFinancGoods31(String financGoods31) {
		this.financGoods31 = financGoods31;
	}

	public String getFinancGoods32() {
		return financGoods32;
	}

	public void setFinancGoods32(String financGoods32) {
		this.financGoods32 = financGoods32;
	}

	public String getBillType() {
		return billType;
	}

	public void setBillType(String billType) {
		this.billType = billType;
	}

	public String getBillCycle() {
		return billCycle;
	}

	public void setBillCycle(String billCycle) {
		this.billCycle = billCycle;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public String getLoanNotifyType() {
		return loanNotifyType;
	}

	public void setLoanNotifyType(String loanNotifyType) {
		this.loanNotifyType = loanNotifyType;
	}

	public String getSbuBillDt() {
		return sbuBillDt;
	}

	public void setSbuBillDt(String sbuBillDt) {
		this.sbuBillDt = sbuBillDt;
	}

	public String getHeadOffice() {
		return headOffice;
	}

	public void setHeadOffice(String headOffice) {
		this.headOffice = headOffice;
	}

	public String getBankslipNonmail() {
		return bankslipNonmail;
	}

	public void setBankslipNonmail(String bankslipNonmail) {
		this.bankslipNonmail = bankslipNonmail;
	}

	public String getWdmsId() {
		return wdmsId;
	}

	public void setWdmsId(String wdmsId) {
		this.wdmsId = wdmsId;
	}

	public String getOpenAim() {
		return openAim;
	}

	public void setOpenAim(String openAim) {
		this.openAim = openAim;
	}

	public String getWaiveAdjCnt() {
		return waiveAdjCnt;
	}

	public void setWaiveAdjCnt(String waiveAdjCnt) {
		this.waiveAdjCnt = waiveAdjCnt;
	}

	public String getPromCode() {
		return promCode;
	}

	public void setPromCode(String promCode) {
		this.promCode = promCode;
	}

	public String getSetStatus() {
		return setStatus;
	}

	public void setSetStatus(String setStatus) {
		this.setStatus = setStatus;
	}

	public String getSetStatusDate() {
		return setStatusDate;
	}

	public void setSetStatusDate(String setStatusDate) {
		this.setStatusDate = setStatusDate;
	}

	public String getComplxStructFlag() {
		return complxStructFlag;
	}

	public void setComplxStructFlag(String complxStructFlag) {
		this.complxStructFlag = complxStructFlag;
	}

	public String getNonRegisterFlag() {
		return nonRegisterFlag;
	}

	public void setNonRegisterFlag(String nonRegisterFlag) {
		this.nonRegisterFlag = nonRegisterFlag;
	}

	public String getSwiftCode() {
		return swiftCode;
	}

	public void setSwiftCode(String swiftCode) {
		this.swiftCode = swiftCode;
	}

	public String getSmeCorpFlag() {
		return smeCorpFlag;
	}

	public void setSmeCorpFlag(String smeCorpFlag) {
		this.smeCorpFlag = smeCorpFlag;
	}

	public String getSetPurpose() {
		return setPurpose;
	}

	public void setSetPurpose(String setPurpose) {
		this.setPurpose = setPurpose;
	}

	public String getAmlPriBusNation() {
		return amlPriBusNation;
	}

	public void setAmlPriBusNation(String amlPriBusNation) {
		this.amlPriBusNation = amlPriBusNation;
	}

	public String getAmlBusNationRisk() {
		return amlBusNationRisk;
	}

	public void setAmlBusNationRisk(String amlBusNationRisk) {
		this.amlBusNationRisk = amlBusNationRisk;
	}

	public String getAmlBusNationRisk1() {
		return amlBusNationRisk1;
	}

	public void setAmlBusNationRisk1(String amlBusNationRisk1) {
		this.amlBusNationRisk1 = amlBusNationRisk1;
	}

	public String getAmlBusNationRisk2() {
		return amlBusNationRisk2;
	}

	public void setAmlBusNationRisk2(String amlBusNationRisk2) {
		this.amlBusNationRisk2 = amlBusNationRisk2;
	}

	public String getAmlBusNationRisk3() {
		return amlBusNationRisk3;
	}

	public void setAmlBusNationRisk3(String amlBusNationRisk3) {
		this.amlBusNationRisk3 = amlBusNationRisk3;
	}

	public String getAmlBusNationRisk4() {
		return amlBusNationRisk4;
	}

	public void setAmlBusNationRisk4(String amlBusNationRisk4) {
		this.amlBusNationRisk4 = amlBusNationRisk4;
	}

	public String getAmlBusNationRisk5() {
		return amlBusNationRisk5;
	}

	public void setAmlBusNationRisk5(String amlBusNationRisk5) {
		this.amlBusNationRisk5 = amlBusNationRisk5;
	}

	public String getAmlOversFor() {
		return amlOversFor;
	}

	public void setAmlOversFor(String amlOversFor) {
		this.amlOversFor = amlOversFor;
	}

	public String getAmlOversForNation() {
		return amlOversForNation;
	}

	public void setAmlOversForNation(String amlOversForNation) {
		this.amlOversForNation = amlOversForNation;
	}

}
