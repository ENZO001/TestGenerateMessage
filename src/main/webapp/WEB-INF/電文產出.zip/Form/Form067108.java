package com.ctbcbank.pcms.form;

import com.ctbcbank.pcms.htg.BaseForm;

public class Form067108 extends BaseForm {

	private static final long serialVersionUID = 1L;

	private String option;
	private String custIdNo;
	private String idType;
	private String docuType;
	private String agreYear;
	private String agreMonth;
	private String name;
	private String promoCode;
	private String recBrch;
	private String recUid;
	private String recDate;
	private String custNo;
	private String signdate;
	private String basicAgree;
	private String otherAgree;
	private String agreDd;
	private String subComp1; // 中國信託保險經紀人
	private String subComp2; // 中國信託綜合證券
	private String subComp3; // 台灣彩券
	private String subComp4; // 保留
	private String subComp5; // 保留
	private String subComp6; // 保留
	private String lastListFlg; // 主機判斷用欄位畫面不顯示
	private String underAge; // 主機判斷用欄位畫面不顯示
	private String promoterId; // 推廣員
	private String buiAgreeFlg; // 暫停房貸電話行銷
	private String buiStopDays; // 暫停房貸電話行銷天數
	private String buiStopDate; // 暫停房貸電話行銷止日
	private String fidAgreeFlg; // 暫停信貸電話行銷
	private String fidStopDays; // 暫停信貸電話行銷天數
	private String fidStopDate; // 暫停信貸電話行銷止日
	private String insAgreeFlg; // 暫停保險電話行銷
	private String insStopDays; // 暫停保險電話行銷天數
	private String insStopDate; // 暫停保險電話行銷止日
	private String memo; // 個人資料運用告知同意書-備註
	private String maturityDate; // 到期日期
	private String kycType; // KYC分類
	private String hedgeType; // 客戶分類
	private String totalAssetAmt; // 新台幣資產總額，單位：仟元
	private String subcontFlag; // 增補擔保品約款同意書
	private String du48JobFlag; // 48書類本人任職期間註記
	private String du48CardFlag; // 48書類信用卡有效期間註記
	private String du48AcctNo; // 48書類圈存帳號

	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

	public String getCustIdNo() {
		return custIdNo;
	}

	public void setCustIdNo(String custIdNo) {
		this.custIdNo = custIdNo;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getDocuType() {
		return docuType;
	}

	public void setDocuType(String docuType) {
		this.docuType = docuType;
	}

	public String getAgreYear() {
		return agreYear;
	}

	public void setAgreYear(String agreYear) {
		this.agreYear = agreYear;
	}

	public String getAgreMonth() {
		return agreMonth;
	}

	public void setAgreMonth(String agreMonth) {
		this.agreMonth = agreMonth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPromoCode() {
		return promoCode;
	}

	public void setPromoCode(String promoCode) {
		this.promoCode = promoCode;
	}

	public String getRecBrch() {
		return recBrch;
	}

	public void setRecBrch(String recBrch) {
		this.recBrch = recBrch;
	}

	public String getRecUid() {
		return recUid;
	}

	public void setRecUid(String recUid) {
		this.recUid = recUid;
	}

	public String getRecDate() {
		return recDate;
	}

	public void setRecDate(String recDate) {
		this.recDate = recDate;
	}

	public String getCustNo() {
		return custNo;
	}

	public void setCustNo(String custNo) {
		this.custNo = custNo;
	}

	public String getSigndate() {
		return signdate;
	}

	public void setSigndate(String signdate) {
		this.signdate = signdate;
	}

	public String getBasicAgree() {
		return basicAgree;
	}

	public void setBasicAgree(String basicAgree) {
		this.basicAgree = basicAgree;
	}

	public String getOtherAgree() {
		return otherAgree;
	}

	public void setOtherAgree(String otherAgree) {
		this.otherAgree = otherAgree;
	}

	public String getAgreDd() {
		return agreDd;
	}

	public void setAgreDd(String agreDd) {
		this.agreDd = agreDd;
	}

	public String getSubComp1() {
		return subComp1;
	}

	public void setSubComp1(String subComp1) {
		this.subComp1 = subComp1;
	}

	public String getSubComp2() {
		return subComp2;
	}

	public void setSubComp2(String subComp2) {
		this.subComp2 = subComp2;
	}

	public String getSubComp3() {
		return subComp3;
	}

	public void setSubComp3(String subComp3) {
		this.subComp3 = subComp3;
	}

	public String getSubComp4() {
		return subComp4;
	}

	public void setSubComp4(String subComp4) {
		this.subComp4 = subComp4;
	}

	public String getSubComp5() {
		return subComp5;
	}

	public void setSubComp5(String subComp5) {
		this.subComp5 = subComp5;
	}

	public String getSubComp6() {
		return subComp6;
	}

	public void setSubComp6(String subComp6) {
		this.subComp6 = subComp6;
	}

	public String getLastListFlg() {
		return lastListFlg;
	}

	public void setLastListFlg(String lastListFlg) {
		this.lastListFlg = lastListFlg;
	}

	public String getUnderAge() {
		return underAge;
	}

	public void setUnderAge(String underAge) {
		this.underAge = underAge;
	}

	public String getPromoterId() {
		return promoterId;
	}

	public void setPromoterId(String promoterId) {
		this.promoterId = promoterId;
	}

	public String getBuiAgreeFlg() {
		return buiAgreeFlg;
	}

	public void setBuiAgreeFlg(String buiAgreeFlg) {
		this.buiAgreeFlg = buiAgreeFlg;
	}

	public String getBuiStopDays() {
		return buiStopDays;
	}

	public void setBuiStopDays(String buiStopDays) {
		this.buiStopDays = buiStopDays;
	}

	public String getBuiStopDate() {
		return buiStopDate;
	}

	public void setBuiStopDate(String buiStopDate) {
		this.buiStopDate = buiStopDate;
	}

	public String getFidAgreeFlg() {
		return fidAgreeFlg;
	}

	public void setFidAgreeFlg(String fidAgreeFlg) {
		this.fidAgreeFlg = fidAgreeFlg;
	}

	public String getFidStopDays() {
		return fidStopDays;
	}

	public void setFidStopDays(String fidStopDays) {
		this.fidStopDays = fidStopDays;
	}

	public String getFidStopDate() {
		return fidStopDate;
	}

	public void setFidStopDate(String fidStopDate) {
		this.fidStopDate = fidStopDate;
	}

	public String getInsAgreeFlg() {
		return insAgreeFlg;
	}

	public void setInsAgreeFlg(String insAgreeFlg) {
		this.insAgreeFlg = insAgreeFlg;
	}

	public String getInsStopDays() {
		return insStopDays;
	}

	public void setInsStopDays(String insStopDays) {
		this.insStopDays = insStopDays;
	}

	public String getInsStopDate() {
		return insStopDate;
	}

	public void setInsStopDate(String insStopDate) {
		this.insStopDate = insStopDate;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getKycType() {
		return kycType;
	}

	public void setKycType(String kycType) {
		this.kycType = kycType;
	}

	public String getHedgeType() {
		return hedgeType;
	}

	public void setHedgeType(String hedgeType) {
		this.hedgeType = hedgeType;
	}

	public String getTotalAssetAmt() {
		return totalAssetAmt;
	}

	public void setTotalAssetAmt(String totalAssetAmt) {
		this.totalAssetAmt = totalAssetAmt;
	}

	public String getSubcontFlag() {
		return subcontFlag;
	}

	public void setSubcontFlag(String subcontFlag) {
		this.subcontFlag = subcontFlag;
	}

	public String getDu48JobFlag() {
		return du48JobFlag;
	}

	public void setDu48JobFlag(String du48JobFlag) {
		this.du48JobFlag = du48JobFlag;
	}

	public String getDu48CardFlag() {
		return du48CardFlag;
	}

	public void setDu48CardFlag(String du48CardFlag) {
		this.du48CardFlag = du48CardFlag;
	}

	public String getDu48AcctNo() {
		return du48AcctNo;
	}

	public void setDu48AcctNo(String du48AcctNo) {
		this.du48AcctNo = du48AcctNo;
	}

}
