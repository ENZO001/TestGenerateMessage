package com.ctbcbank.pcms.rtn;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form002000;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public class Rtn002000 extends RtnBase {

	public boolean msgParser(Document document, BaseForm form) throws Exception {

		Element elementValue;

		Form002000 fm = (Form002000) form;

		String temp = document.valueOf("hostgateway/line[@no='1']/msgBody/data[@id='outputCode']/@value");
		int j = 0;
		if (!temp.equals("03")) {
			j = 2;
		} else {
			j = 1;
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SACCTNO']");
		if (elementValue != null) {
			fm.setSacctno(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SACCTNO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUSTNO']");
		if (elementValue != null) {
			fm.setCustno(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUSTNO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ID_NO']");
		if (elementValue != null) {
			fm.setCustIdNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ID_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='IDTYPE']");
		if (elementValue != null) {
			fm.setIdtype(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='IDTYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ACCNAME']");
		if (elementValue != null) {
			fm.setAccname(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ACCNAME']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ADDRESS1']");
		if (elementValue != null) {
			fm.setAddress1(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ADDRESS1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ADDRESS2']");
		if (elementValue != null) {
			fm.setAddress2(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ADDRESS2']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FIELD1']");
		if (elementValue != null) {
			fm.setField1(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FIELD1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ADDRESS3']");
		if (elementValue != null) {
			fm.setAddress3(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ADDRESS3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CURRENC3']");
		if (elementValue != null) {
			fm.setCurrenc3(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CURRENC3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ADDRESS4']");
		if (elementValue != null) {
			fm.setAddress4(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ADDRESS4']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='POSTCODE']");
		if (elementValue != null) {
			fm.setPostcode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='POSTCODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ACCTTYPE']");
		if (elementValue != null) {
			fm.setAccttype(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ACCTTYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INTCAT']");
		if (elementValue != null) {
			fm.setIntcat(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INTCAT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='LEGALENT']");
		if (elementValue != null) {
			fm.setLegalent(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='LEGALENT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE1']");
		if (elementValue != null) {
			fm.setSpace1(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INTPAYMETHOD']");
		if (elementValue != null) {
			fm.setIntpaymethod(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INTPAYMETHOD']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE2']");
		if (elementValue != null) {
			fm.setSpace2(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE2']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TFRACCTNO']");
		if (elementValue != null) {
			fm.setTfracctno(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TFRACCTNO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CHEXPRO']");
		if (elementValue != null) {
			fm.setChexpro(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CHEXPRO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='LANGCODE']");
		if (elementValue != null) {
			fm.setLangcode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='LANGCODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FREQ']");
		if (elementValue != null) {
			fm.setFreq(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FREQ']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE3']");
		if (elementValue != null) {
			fm.setSpace3(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='STDAIND']");
		if (elementValue != null) {
			fm.setStdaind(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='STDAIND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MAILIND']");
		if (elementValue != null) {
			fm.setMailind(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MAILIND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NOTIND']");
		if (elementValue != null) {
			fm.setNotind(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NOTIND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NOTCUST']");
		if (elementValue != null) {
			fm.setNotcust(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NOTCUST']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='VAINRATE']");
		if (elementValue != null) {
			fm.setVainrate(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='VAINRATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE4']");
		if (elementValue != null) {
			fm.setSpace4(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE4']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INTFREQ']");
		if (elementValue != null) {
			fm.setIntfreq(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INTFREQ']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CYCLE']");
		if (elementValue != null) {
			fm.setCycle(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CYCLE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DAY']");
		if (elementValue != null) {
			fm.setDay(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DAY']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AGENTCD']");
		if (elementValue != null) {
			fm.setAgentcd(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AGENTCD']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INVTYPE']");
		if (elementValue != null) {
			fm.setInvtype(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INVTYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DISTRICT']");
		if (elementValue != null) {
			fm.setDistrict(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DISTRICT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SEGMENT_CODE']");
		if (elementValue != null) {
			fm.setSegmentCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SEGMENT_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE5']");
		if (elementValue != null) {
			fm.setSpace5(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE5']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BUSSINESS_TYPE']");
		if (elementValue != null) {
			fm.setBussinessType(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BUSSINESS_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE6']");
		if (elementValue != null) {
			fm.setSpace6(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE6']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='GROUPIND']");
		if (elementValue != null) {
			fm.setGroupind(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='GROUPIND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FACNO']");
		if (elementValue != null) {
			fm.setFacno(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FACNO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='APPLID']");
		if (elementValue != null) {
			fm.setApplid(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='APPLID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE7']");
		if (elementValue != null) {
			fm.setSpace7(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE7']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='VISAFLAG']");
		if (elementValue != null) {
			fm.setVisaflag(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='VISAFLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='VISECODE']");
		if (elementValue != null) {
			fm.setVisecode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='VISECODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='VICRLIM']");
		if (elementValue != null) {
			fm.setVicrlim(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='VICRLIM']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE8']");
		if (elementValue != null) {
			fm.setSpace8(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE8']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TERMLENGTH']");
		if (elementValue != null) {
			fm.setTermlength(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TERMLENGTH']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FREQUENCY_CODE']");
		if (elementValue != null) {
			fm.setFrequencyCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FREQUENCY_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TERMVAL']");
		if (elementValue != null) {
			fm.setTermval(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TERMVAL']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE9']");
		if (elementValue != null) {
			fm.setSpace9(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE9']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TIGRID']");
		if (elementValue != null) {
			fm.setTigrid(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TIGRID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CURIDORI']");
		if (elementValue != null) {
			fm.setCuridori(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CURIDORI']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUSTRISK']");
		if (elementValue != null) {
			fm.setCustrisk(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUSTRISK']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ARCBRISK']");
		if (elementValue != null) {
			fm.setArcbrisk(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ARCBRISK']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SECIND']");
		if (elementValue != null) {
			fm.setSecind(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SECIND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TIMEBAND']");
		if (elementValue != null) {
			fm.setTimeband(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TIMEBAND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BANKID']");
		if (elementValue != null) {
			fm.setBankid(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BANKID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE10']");
		if (elementValue != null) {
			fm.setSpace10(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE10']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OPENDATE']");
		if (elementValue != null) {
			fm.setOpendate(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OPENDATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COPIES']");
		if (elementValue != null) {
			fm.setCopies(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COPIES']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FILLER5']");
		if (elementValue != null) {
			fm.setFiller5(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FILLER5']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ACEXIND']");
		if (elementValue != null) {
			fm.setAcexind(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ACEXIND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MATRATE']");
		if (elementValue != null) {
			fm.setMatrate(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MATRATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FILLER6']");
		if (elementValue != null) {
			fm.setFiller6(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FILLER6']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CERTIFICATENO']");
		if (elementValue != null) {
			fm.setCertificateno(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CERTIFICATENO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='RATE_TYPE']");
		if (elementValue != null) {
			fm.setRateType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='RATE_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='STAMP_TAX_FLAG']");
		if (elementValue != null) {
			fm.setStampTaxFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='STAMP_TAX_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='RATEINCR']");
		if (elementValue != null) {
			fm.setRateincr(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='RATEINCR']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REFERRAL']");
		if (elementValue != null) {
			fm.setReferral(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REFERRAL']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE11']");
		if (elementValue != null) {
			fm.setSpace11(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE11']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='GLCC']");
		if (elementValue != null) {
			fm.setGlcc(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='GLCC']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SECURITYNO']");
		if (elementValue != null) {
			fm.setSecurityno(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SECURITYNO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='EMPNO']");
		if (elementValue != null) {
			fm.setEmpno(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='EMPNO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OMNIBUS']");
		if (elementValue != null) {
			fm.setOmnibus(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OMNIBUS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PROMCODE']");
		if (elementValue != null) {
			fm.setPromcode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PROMCODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SPACE12']");
		if (elementValue != null) {
			fm.setSpace12(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SPACE12']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INVESTCODE']");
		if (elementValue != null) {
			fm.setInvestcode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INVESTCODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OMNIBUSACCT']");
		if (elementValue != null) {
			fm.setOmnibusacct(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OMNIBUSACCT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TLR_FLAG']");
		if (elementValue != null) {
			fm.setTlrFlag(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TLR_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='RT_LIMIT']");
		if (elementValue != null) {
			fm.setRtLimit(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='RT_LIMIT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INVESTTYPE']");
		if (elementValue != null) {
			fm.setInvesttype(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INVESTTYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TRUST_PROD_MEMO']");
		if (elementValue != null) {
			fm.setTrustProdMemo(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TRUST_PROD_MEMO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PUBLISH_NO']");
		if (elementValue != null) {
			fm.setPublishNo(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PUBLISH_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BILLS_NO']");
		if (elementValue != null) {
			fm.setBillsNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BILLS_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PORTFOLIO_NO']");
		if (elementValue != null) {
			fm.setPortfolioNo(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PORTFOLIO_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OPEN_PURPOSE']");
		if (elementValue != null) {
			fm.setOpenPurpose(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OPEN_PURPOSE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NCD_REGISTERED']");
		if (elementValue != null) {
			fm.setNcdRegistered(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NCD_REGISTERED']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PERSON_FLAG']");
		if (elementValue != null) {
			fm.setPersonFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PERSON_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AUTO_ROLL']");
		if (elementValue != null) {
			fm.setAutoRoll(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AUTO_ROLL']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MNTHY_ESTI_DEP_CNT']");
		if (elementValue != null) {
			fm.setMnthyEstiDepCnt(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MNTHY_ESTI_DEP_CNT']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='MNTHY_ESTI_DEP_AMT_TWD']");
		if (elementValue != null) {
			fm.setMnthyEstiDepAmtTwd(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MNTHY_ESTI_DEP_AMT_TWD']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='MNTHY_ESTI_DEP_AMT_USD']");
		if (elementValue != null) {
			fm.setMnthyEstiDepAmtUsd(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MNTHY_ESTI_DEP_AMT_USD']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MNTHY_ESTI_WDL_CNT']");
		if (elementValue != null) {
			fm.setMnthyEstiWdlCnt(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MNTHY_ESTI_WDL_CNT']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='MNTHY_ESTI_WDL_AMT_TWD']");
		if (elementValue != null) {
			fm.setMnthyEstiWdlAmtTwd(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MNTHY_ESTI_WDL_AMT_TWD']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='MNTHY_ESTI_WDL_AMT_USD']");
		if (elementValue != null) {
			fm.setMnthyEstiWdlAmtUsd(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MNTHY_ESTI_WDL_AMT_USD']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='I_USE_FLAG']");
		if (elementValue != null) {
			fm.setiUseFlag(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='I_USE_FLAG']/@value"));
		}

		return true;
	}
}
