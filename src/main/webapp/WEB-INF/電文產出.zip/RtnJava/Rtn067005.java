package com.ctbcbank.pcms.rtn;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form067005;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public class Rtn067005 extends RtnBase {

	public boolean msgParser(Document document, BaseForm form) throws Exception {

		Element elementValue;

		Form067005 fm = (Form067005) form;

		String temp = document.valueOf("hostgateway/line[@no='1']/msgBody/data[@id='outputCode']/@value");
		int j = 0;
		if (!temp.equals("03")) {
			j = 2;
		} else {
			j = 1;
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CIF_NO']");
		if (elementValue != null) {
			fm.setCifNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CIF_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ID_NO']");
		if (elementValue != null) {
			fm.setCustIdNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ID_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ID_TYP']");
		if (elementValue != null) {
			fm.setCustIdTyp(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ID_TYP']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUSTOMER_NAME']");
		if (elementValue != null) {
			fm.setCustomerName(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUSTOMER_NAME']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DAYTEL_NO']");
		if (elementValue != null) {
			fm.setDaytelNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DAYTEL_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DAYTEL_TXT']");
		if (elementValue != null) {
			fm.setDaytelTxt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DAYTEL_TXT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DAYTEL_ERR_DATE']");
		if (elementValue != null) {
			fm.setDaytelErrDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DAYTEL_ERR_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NIGTEL_NO']");
		if (elementValue != null) {
			fm.setNigtelNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NIGTEL_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NIGTEL_EXT']");
		if (elementValue != null) {
			fm.setNigtelExt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NIGTEL_EXT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NIGTEL_ERR_DATE']");
		if (elementValue != null) {
			fm.setNigtelErrDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NIGTEL_ERR_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MOBIL_NO']");
		if (elementValue != null) {
			fm.setMobilNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MOBIL_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MOBIL_NO_EXT']");
		if (elementValue != null) {
			fm.setMobilNoExt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MOBIL_NO_EXT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MOBIL_ERR_DATE']");
		if (elementValue != null) {
			fm.setMobilErrDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MOBIL_ERR_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='POST_CODE']");
		if (elementValue != null) {
			fm.setPostCode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='POST_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ADDR_ERR_DATE']");
		if (elementValue != null) {
			fm.setAddrErrDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ADDR_ERR_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMM_ADDR1']");
		if (elementValue != null) {
			fm.setCommAddr1(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMM_ADDR1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMM_ADDR2']");
		if (elementValue != null) {
			fm.setCommAddr2(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMM_ADDR2']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMM_ADDR3']");
		if (elementValue != null) {
			fm.setCommAddr3(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMM_ADDR3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMM_ADDR4']");
		if (elementValue != null) {
			fm.setCommAddr4(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMM_ADDR4']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ZIP_CODE']");
		if (elementValue != null) {
			fm.setZipCode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ZIP_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ERR_DAT']");
		if (elementValue != null) {
			fm.setErrDat(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ERR_DAT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ADD1']");
		if (elementValue != null) {
			fm.setCustAdd1(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ADD1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ADD2']");
		if (elementValue != null) {
			fm.setCustAdd2(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ADD2']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ADD3']");
		if (elementValue != null) {
			fm.setCustAdd3(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ADD3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ADD4']");
		if (elementValue != null) {
			fm.setCustAdd4(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ADD4']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='EMAIL_ERR_DATE']");
		if (elementValue != null) {
			fm.setEmailErrDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='EMAIL_ERR_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='EMAIL_ADDR']");
		if (elementValue != null) {
			fm.setEmailAddr(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='EMAIL_ADDR']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PAGER_NO']");
		if (elementValue != null) {
			fm.setPagerNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PAGER_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PAGER_NO_EXT']");
		if (elementValue != null) {
			fm.setPagerNoExt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PAGER_NO_EXT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PAGER_ERR_DATE']");
		if (elementValue != null) {
			fm.setPagerErrDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PAGER_ERR_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OTHER_PERSON']");
		if (elementValue != null) {
			fm.setOtherPerson(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OTHER_PERSON']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MAIL_IND']");
		if (elementValue != null) {
			fm.setMailInd(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MAIL_IND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FILLER5']");
		if (elementValue != null) {
			fm.setFiller5(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FILLER5']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DAYTEL_UPD_STS']");
		if (elementValue != null) {
			fm.setDaytelUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DAYTEL_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NIGTEL_UPD_STS']");
		if (elementValue != null) {
			fm.setNigtelUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NIGTEL_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MOBIL_UPD_STS']");
		if (elementValue != null) {
			fm.setMobilUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MOBIL_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMM_ADDR_UPD_STS']");
		if (elementValue != null) {
			fm.setCommAddrUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMM_ADDR_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ADDR_UPD_STS']");
		if (elementValue != null) {
			fm.setCustAddrUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ADDR_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='EMAIL_UPD_STS']");
		if (elementValue != null) {
			fm.setEmailUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='EMAIL_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PAGER_UPD_STS']");
		if (elementValue != null) {
			fm.setPagerUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PAGER_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REGTEL_NO']");
		if (elementValue != null) {
			fm.setRegtelNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REGTEL_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REGTEL_NO_EXT']");
		if (elementValue != null) {
			fm.setRegtelNoExt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REGTEL_NO_EXT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REGTEL_UPD_STS']");
		if (elementValue != null) {
			fm.setRegtelUpdSts(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REGTEL_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REGTEL_UPD_DATE']");
		if (elementValue != null) {
			fm.setRegtelUpdDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REGTEL_UPD_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FUND_CIF']");
		if (elementValue != null) {
			fm.setFundCif(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FUND_CIF']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CONFIRM_DATA_DATE']");
		if (elementValue != null) {
			fm.setConfirmDataDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CONFIRM_DATA_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CONF_FLAG']");
		if (elementValue != null) {
			fm.setConfFlag(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CONF_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DATE_OF_BIRTH']");
		if (elementValue != null) {
			fm.setDateOfBirth(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DATE_OF_BIRTH']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BILL_TYPE']");
		if (elementValue != null) {
			fm.setBillType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BILL_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ID_UPD_STS']");
		if (elementValue != null) {
			fm.setIdUpdSts(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ID_UPD_STS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ID_UPD_DATE']");
		if (elementValue != null) {
			fm.setIdUpdDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ID_UPD_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUSTOMER_TYPE']");
		if (elementValue != null) {
			fm.setCustomerType(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUSTOMER_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FUND']");
		if (elementValue != null) {
			fm.setFund(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FUND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AUDIO_CODE']");
		if (elementValue != null) {
			fm.setAudioCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AUDIO_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='VIP_DEGREE']");
		if (elementValue != null) {
			fm.setVipDegree(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='VIP_DEGREE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SEGMENT_CODE']");
		if (elementValue != null) {
			fm.setSegmentCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SEGMENT_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='UCODE']");
		if (elementValue != null) {
			fm.setUcode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='UCODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMM_NAT_CODE']");
		if (elementValue != null) {
			fm.setCommNatCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMM_NAT_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REG_NAT_CODE']");
		if (elementValue != null) {
			fm.setRegNatCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REG_NAT_CODE']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_REGISTRATION_NATION']");
		if (elementValue != null) {
			fm.setAmlRegistrationNation(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_REGISTRATION_NATION']/@value"));
		}

		return true;
	}
}
