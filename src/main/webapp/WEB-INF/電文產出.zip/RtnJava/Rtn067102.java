package com.ctbcbank.pcms.rtn;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form067102;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public class Rtn067102 extends RtnBase {

	public boolean msgParser(Document document, BaseForm form) throws Exception {

		Element elementValue;

		Form067102 fm = (Form067102) form;

		String temp = document.valueOf("hostgateway/line[@no='1']/msgBody/data[@id='outputCode']/@value");
		int j = 0;
		if (!temp.equals("03")) {
			j = 2;
		} else {
			j = 1;
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CIF_NO']");
		if (elementValue != null) {
			fm.setCifNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CIF_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_NAME']");
		if (elementValue != null) {
			fm.setCustName(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_NAME']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REG_CMPY_NO']");
		if (elementValue != null) {
			fm.setRegCmpyNo(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REG_CMPY_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NAME_01']");
		if (elementValue != null) {
			fm.setName01(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NAME_01']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TITLE_CODE_01']");
		if (elementValue != null) {
			fm.setTitleCode01(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TITLE_CODE_01']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TITLE_DESC_01']");
		if (elementValue != null) {
			fm.setTitleDesc01(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TITLE_DESC_01']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NAME_02']");
		if (elementValue != null) {
			fm.setName02(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NAME_02']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TITLE_CODE_02']");
		if (elementValue != null) {
			fm.setTitleCode02(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TITLE_CODE_02']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TITLE_DESC_03']");
		if (elementValue != null) {
			fm.setTitleDesc03(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TITLE_DESC_03']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TRAD_LIC_NO']");
		if (elementValue != null) {
			fm.setTradLicNo(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TRAD_LIC_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REG_BIS_NO']");
		if (elementValue != null) {
			fm.setRegBisNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REG_BIS_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ID_NO']");
		if (elementValue != null) {
			fm.setCustIdNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ID_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ID_TYPE']");
		if (elementValue != null) {
			fm.setIdType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ID_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='RESP_CUST_ID']");
		if (elementValue != null) {
			fm.setRespCustId(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='RESP_CUST_ID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='RESP_ID_TYPE']");
		if (elementValue != null) {
			fm.setRespIdType(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='RESP_ID_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='RESP_NAME']");
		if (elementValue != null) {
			fm.setRespName(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='RESP_NAME']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MAIL_IND']");
		if (elementValue != null) {
			fm.setMailInd(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MAIL_IND']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INCOME_AMT']");
		if (elementValue != null) {
			fm.setIncomeAmt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INCOME_AMT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_1']");
		if (elementValue != null) {
			fm.setFinancGoods1(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_2']");
		if (elementValue != null) {
			fm.setFinancGoods2(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_2']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_3']");
		if (elementValue != null) {
			fm.setFinancGoods3(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_4']");
		if (elementValue != null) {
			fm.setFinancGoods4(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_4']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_5']");
		if (elementValue != null) {
			fm.setFinancGoods5(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_5']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_6']");
		if (elementValue != null) {
			fm.setFinancGoods6(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_6']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_7']");
		if (elementValue != null) {
			fm.setFinancGoods7(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_7']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_8']");
		if (elementValue != null) {
			fm.setFinancGoods8(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_8']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_9']");
		if (elementValue != null) {
			fm.setFinancGoods9(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_9']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_10']");
		if (elementValue != null) {
			fm.setFinancGoods10(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_10']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_11']");
		if (elementValue != null) {
			fm.setFinancGoods11(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_11']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_12']");
		if (elementValue != null) {
			fm.setFinancGoods12(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_12']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_13']");
		if (elementValue != null) {
			fm.setFinancGoods13(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_13']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_14']");
		if (elementValue != null) {
			fm.setFinancGoods14(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_14']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_15']");
		if (elementValue != null) {
			fm.setFinancGoods15(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_15']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_16']");
		if (elementValue != null) {
			fm.setFinancGoods16(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_16']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_17']");
		if (elementValue != null) {
			fm.setFinancGoods17(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_17']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_18']");
		if (elementValue != null) {
			fm.setFinancGoods18(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_18']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_19']");
		if (elementValue != null) {
			fm.setFinancGoods19(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_19']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_20']");
		if (elementValue != null) {
			fm.setFinancGoods20(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_20']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_21']");
		if (elementValue != null) {
			fm.setFinancGoods21(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_21']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_22']");
		if (elementValue != null) {
			fm.setFinancGoods22(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_22']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_23']");
		if (elementValue != null) {
			fm.setFinancGoods23(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_23']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_24']");
		if (elementValue != null) {
			fm.setFinancGoods24(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_24']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_25']");
		if (elementValue != null) {
			fm.setFinancGoods25(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_25']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_26']");
		if (elementValue != null) {
			fm.setFinancGoods26(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_26']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_27']");
		if (elementValue != null) {
			fm.setFinancGoods27(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_27']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_28']");
		if (elementValue != null) {
			fm.setFinancGoods28(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_28']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_29']");
		if (elementValue != null) {
			fm.setFinancGoods29(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_29']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_30']");
		if (elementValue != null) {
			fm.setFinancGoods30(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_30']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_31']");
		if (elementValue != null) {
			fm.setFinancGoods31(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_31']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FINANC_GOODS_32']");
		if (elementValue != null) {
			fm.setFinancGoods32(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FINANC_GOODS_32']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BILL_TYPE']");
		if (elementValue != null) {
			fm.setBillType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BILL_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BILL_CYCLE']");
		if (elementValue != null) {
			fm.setBillCycle(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BILL_CYCLE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BILL_DATE']");
		if (elementValue != null) {
			fm.setBillDate(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BILL_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='LOAN_NOTIFY_TYPE']");
		if (elementValue != null) {
			fm.setLoanNotifyType(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='LOAN_NOTIFY_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SBU_BILL_DT']");
		if (elementValue != null) {
			fm.setSbuBillDt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SBU_BILL_DT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='HEAD_OFFICE']");
		if (elementValue != null) {
			fm.setHeadOffice(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='HEAD_OFFICE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BANKSLIP_NONMAIL']");
		if (elementValue != null) {
			fm.setBankslipNonmail(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BANKSLIP_NONMAIL']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='WDMS_ID']");
		if (elementValue != null) {
			fm.setWdmsId(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='WDMS_ID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OPEN_AIM']");
		if (elementValue != null) {
			fm.setOpenAim(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OPEN_AIM']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='WAIVE_ADJ_CNT']");
		if (elementValue != null) {
			fm.setWaiveAdjCnt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='WAIVE_ADJ_CNT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PROM_CODE']");
		if (elementValue != null) {
			fm.setPromCode(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PROM_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SET_STATUS']");
		if (elementValue != null) {
			fm.setSetStatus(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SET_STATUS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SET_STATUS_DATE']");
		if (elementValue != null) {
			fm.setSetStatusDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SET_STATUS_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='COMPLX_STRUCT_FLAG']");
		if (elementValue != null) {
			fm.setComplxStructFlag(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='COMPLX_STRUCT_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NON_REGISTER_FLAG']");
		if (elementValue != null) {
			fm.setNonRegisterFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NON_REGISTER_FLAG']/@value"));

		}
		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SWIFT_CODE']");
		if (elementValue != null) {
			fm.setSwiftCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SWIFT_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SME_CORP_FLAG']");
		if (elementValue != null) {
			fm.setSmeCorpFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SME_CORP_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SET_PURPOSE']");
		if (elementValue != null) {
			fm.setSetPurpose(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SET_PURPOSE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_PRI_BUS_NATION']");
		if (elementValue != null) {
			fm.setAmlPriBusNation(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_PRI_BUS_NATION']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_BUS_NATION_RISK']");
		if (elementValue != null) {
			fm.setAmlBusNationRisk(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_BUS_NATION_RISK']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_BUS_NATION_RISK_1']");
		if (elementValue != null) {
			fm.setAmlBusNationRisk1(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_BUS_NATION_RISK_1']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_BUS_NATION_RISK_2']");
		if (elementValue != null) {
			fm.setAmlBusNationRisk2(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_BUS_NATION_RISK_2']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_BUS_NATION_RISK_3']");
		if (elementValue != null) {
			fm.setAmlBusNationRisk3(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_BUS_NATION_RISK_3']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_BUS_NATION_RISK_4']");
		if (elementValue != null) {
			fm.setAmlBusNationRisk4(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_BUS_NATION_RISK_4']/@value"));
		}

		elementValue = (Element) document
				.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_BUS_NATION_RISK_5']");
		if (elementValue != null) {
			fm.setAmlBusNationRisk5(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_BUS_NATION_RISK_5']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_OVERS_FOR']");
		if (elementValue != null) {
			fm.setAmlOversFor(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_OVERS_FOR']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AML_OVERS_FOR_NATION']");
		if (elementValue != null) {
			fm.setAmlOversForNation(document
					.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AML_OVERS_FOR_NATION']/@value"));
		}

		return true;
	}
}
