package com.ctbcbank.pcms.rtn;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form067108;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public class Rtn067108 extends RtnBase {

	public boolean msgParser(Document document, BaseForm form) throws Exception {

		Element elementValue;

		Form067108 fm = (Form067108) form;

		String temp = document.valueOf("hostgateway/line[@no='1']/msgBody/data[@id='outputCode']/@value");
		int j = 0;
		if (!temp.equals("03")) {
			j = 2;
		} else {
			j = 1;
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OPTION']");
		if (elementValue != null) {
			fm.setOption(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OPTION']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_ID_NO']");
		if (elementValue != null) {
			fm.setCustIdNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_ID_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='ID_TYPE']");
		if (elementValue != null) {
			fm.setIdType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='ID_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DOCU_TYPE']");
		if (elementValue != null) {
			fm.setDocuType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DOCU_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AGRE_YEAR']");
		if (elementValue != null) {
			fm.setAgreYear(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AGRE_YEAR']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AGRE_MONTH']");
		if (elementValue != null) {
			fm.setAgreMonth(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AGRE_MONTH']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='NAME']");
		if (elementValue != null) {
			fm.setName(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='NAME']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PROMO_CODE']");
		if (elementValue != null) {
			fm.setPromoCode(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PROMO_CODE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REC_BRCH']");
		if (elementValue != null) {
			fm.setRecBrch(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REC_BRCH']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REC_UID']");
		if (elementValue != null) {
			fm.setRecUid(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REC_UID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='REC_DATE']");
		if (elementValue != null) {
			fm.setRecDate(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='REC_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='CUST_NO']");
		if (elementValue != null) {
			fm.setCustNo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='CUST_NO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SIGNDATE']");
		if (elementValue != null) {
			fm.setSigndate(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SIGNDATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BASIC_AGREE']");
		if (elementValue != null) {
			fm.setBasicAgree(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BASIC_AGREE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='OTHER_AGREE']");
		if (elementValue != null) {
			fm.setOtherAgree(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='OTHER_AGREE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='AGRE_DD']");
		if (elementValue != null) {
			fm.setAgreDd(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='AGRE_DD']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUB_COMP1']");
		if (elementValue != null) {
			fm.setSubComp1(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUB_COMP1']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUB_COMP2']");
		if (elementValue != null) {
			fm.setSubComp2(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUB_COMP2']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUB_COMP3']");
		if (elementValue != null) {
			fm.setSubComp3(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUB_COMP3']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUB_COMP4']");
		if (elementValue != null) {
			fm.setSubComp4(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUB_COMP4']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUB_COMP5']");
		if (elementValue != null) {
			fm.setSubComp5(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUB_COMP5']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUB_COMP6']");
		if (elementValue != null) {
			fm.setSubComp6(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUB_COMP6']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='LAST_LIST_FLG']");
		if (elementValue != null) {
			fm.setLastListFlg(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='LAST_LIST_FLG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='UNDER_AGE']");
		if (elementValue != null) {
			fm.setUnderAge(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='UNDER_AGE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='PROMOTER_ID']");
		if (elementValue != null) {
			fm.setPromoterId(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='PROMOTER_ID']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BUI_AGREE_FLG']");
		if (elementValue != null) {
			fm.setBuiAgreeFlg(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BUI_AGREE_FLG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BUI_STOP_DAYS']");
		if (elementValue != null) {
			fm.setBuiStopDays(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BUI_STOP_DAYS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='BUI_STOP_DATE']");
		if (elementValue != null) {
			fm.setBuiStopDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='BUI_STOP_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FID_AGREE_FLG']");
		if (elementValue != null) {
			fm.setFidAgreeFlg(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FID_AGREE_FLG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FID_STOP_DAYS']");
		if (elementValue != null) {
			fm.setFidStopDays(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FID_STOP_DAYS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='FID_STOP_DATE']");
		if (elementValue != null) {
			fm.setFidStopDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='FID_STOP_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INS_AGREE_FLG']");
		if (elementValue != null) {
			fm.setInsAgreeFlg(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INS_AGREE_FLG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INS_STOP_DAYS']");
		if (elementValue != null) {
			fm.setInsStopDays(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INS_STOP_DAYS']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='INS_STOP_DATE']");
		if (elementValue != null) {
			fm.setInsStopDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='INS_STOP_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MEMO']");
		if (elementValue != null) {
			fm.setMemo(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MEMO']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='MATURITY_DATE']");
		if (elementValue != null) {
			fm.setMaturityDate(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='MATURITY_DATE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='KYC_TYPE']");
		if (elementValue != null) {
			fm.setKycType(document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='KYC_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='HEDGE_TYPE']");
		if (elementValue != null) {
			fm.setHedgeType(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='HEDGE_TYPE']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='TOTAL_ASSET_AMT']");
		if (elementValue != null) {
			fm.setTotalAssetAmt(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='TOTAL_ASSET_AMT']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='SUBCONT_FLAG']");
		if (elementValue != null) {
			fm.setSubcontFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='SUBCONT_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DU48_JOB_FLAG']");
		if (elementValue != null) {
			fm.setDu48JobFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DU48_JOB_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DU48_CARD_FLAG']");
		if (elementValue != null) {
			fm.setDu48CardFlag(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DU48_CARD_FLAG']/@value"));
		}

		elementValue = (Element) document.selectSingleNode("hostgateway/line/msgBody/data[@id='DU48_ACCT_NO']");
		if (elementValue != null) {
			fm.setDu48AcctNo(
					document.valueOf("hostgateway/line[@no='" + j + "']/msgBody/data[@id='DU48_ACCT_NO']/@value"));
		}

		return true;
	}
}
