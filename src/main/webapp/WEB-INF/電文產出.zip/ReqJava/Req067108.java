package com.ctbcbank.pcms.req;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form067108;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public final class Req067108 extends ReqBase {

	@Override
	public Document fillxmlValue(Document document, BaseForm form, String sessionId) throws Exception {

		Element element;

		if (form instanceof Form067108) {
			Form067108 fm = (Form067108) form;

			// set session id
			element = (Element) document.selectSingleNode("hostgateway/header/data[@id='sessionId']");
			element.addAttribute("value", sessionId);

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='OPTION']");
			element.addAttribute("value", fm.getOption());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CUST_ID_NO']");
			element.addAttribute("value", fm.getCustIdNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='ID_TYPE']");
			element.addAttribute("value", fm.getIdType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='DOCU_TYPE']");
			element.addAttribute("value", fm.getDocuType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AGRE_YEAR']");
			element.addAttribute("value", fm.getAgreYear());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AGRE_MONTH']");
			element.addAttribute("value", fm.getAgreMonth());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='NAME']");
			element.addAttribute("value", fm.getName());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='PROMO_CODE']");
			element.addAttribute("value", fm.getPromoCode());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='REC_BRCH']");
			element.addAttribute("value", fm.getRecBrch());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='REC_UID']");
			element.addAttribute("value", fm.getRecUid());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='REC_DATE']");
			element.addAttribute("value", fm.getRecDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CUST_NO']");
			element.addAttribute("value", fm.getCustNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SIGNDATE']");
			element.addAttribute("value", fm.getSigndate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BASIC_AGREE']");
			element.addAttribute("value", fm.getBasicAgree());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='OTHER_AGREE']");
			element.addAttribute("value", fm.getOtherAgree());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AGRE_DD']");
			element.addAttribute("value", fm.getAgreDd());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUB_COMP1']");
			element.addAttribute("value", fm.getSubComp1());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUB_COMP2']");
			element.addAttribute("value", fm.getSubComp2());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUB_COMP3']");
			element.addAttribute("value", fm.getSubComp3());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUB_COMP4']");
			element.addAttribute("value", fm.getSubComp4());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUB_COMP5']");
			element.addAttribute("value", fm.getSubComp5());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUB_COMP6']");
			element.addAttribute("value", fm.getSubComp6());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='LAST_LIST_FLG']");
			element.addAttribute("value", fm.getLastListFlg());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='UNDER_AGE']");
			element.addAttribute("value", fm.getUnderAge());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='PROMOTER_ID']");
			element.addAttribute("value", fm.getPromoterId());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BUI_AGREE_FLG']");
			element.addAttribute("value", fm.getBuiAgreeFlg());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BUI_STOP_DAYS']");
			element.addAttribute("value", fm.getBuiStopDays());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BUI_STOP_DATE']");
			element.addAttribute("value", fm.getBuiStopDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FID_AGREE_FLG']");
			element.addAttribute("value", fm.getFidAgreeFlg());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FID_STOP_DAYS']");
			element.addAttribute("value", fm.getFidStopDays());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FID_STOP_DATE']");
			element.addAttribute("value", fm.getFidStopDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='INS_AGREE_FLG']");
			element.addAttribute("value", fm.getInsAgreeFlg());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='INS_STOP_DAYS']");
			element.addAttribute("value", fm.getInsStopDays());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='INS_STOP_DATE']");
			element.addAttribute("value", fm.getInsStopDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='MEMO']");
			element.addAttribute("value", fm.getMemo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='MATURITY_DATE']");
			element.addAttribute("value", fm.getMaturityDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='KYC_TYPE']");
			element.addAttribute("value", fm.getKycType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='HEDGE_TYPE']");
			element.addAttribute("value", fm.getHedgeType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='TOTAL_ASSET_AMT']");
			element.addAttribute("value", fm.getHedgeType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SUBCONT_FLAG']");
			element.addAttribute("value", fm.getSubcontFlag());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='DU48_JOB_FLAG']");
			element.addAttribute("value", fm.getDu48JobFlag());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='DU48_CARD_FLAG']");
			element.addAttribute("value", fm.getDu48CardFlag());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='DU48_ACCT_NO']");
			element.addAttribute("value", fm.getDu48AcctNo());
		}

		return document;
	}
}
