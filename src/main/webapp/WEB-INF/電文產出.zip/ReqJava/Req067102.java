package com.ctbcbank.pcms.req;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form067102;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public final class Req067102 extends ReqBase {

	@Override
	public Document fillxmlValue(Document document, BaseForm form, String sessionId) throws Exception {

		Element element;

		if (form instanceof Form067102) {
			Form067102 fm = (Form067102) form;

			// set session id
			element = (Element) document.selectSingleNode("hostgateway/header/data[@id='sessionId']");
			element.addAttribute("value", sessionId);

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CIF_NO']");
			element.addAttribute("value", fm.getCifNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CUST_NAME']");
			element.addAttribute("value", fm.getCustIdNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='REG_CMPY_NO']");
			element.addAttribute("value", fm.getRegCmpyNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='NAME_01']");
			element.addAttribute("value", fm.getName01());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='TITLE_CODE_01']");
			element.addAttribute("value", fm.getTitleCode01());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='TITLE_DESC_01']");
			element.addAttribute("value", fm.getTitleDesc01());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='NAME_02']");
			element.addAttribute("value", fm.getName02());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='TITLE_CODE_02']");
			element.addAttribute("value", fm.getTitleCode02());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='TITLE_DESC_03']");
			element.addAttribute("value", fm.getTitleDesc03());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='TRAD_LIC_NO']");
			element.addAttribute("value", fm.getTradLicNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='REG_BIS_NO']");
			element.addAttribute("value", fm.getRegBisNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CUST_ID_NO']");
			element.addAttribute("value", fm.getCustIdNo());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='ID_TYPE']");
			element.addAttribute("value", fm.getIdType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='RESP_CUST_ID']");
			element.addAttribute("value", fm.getRespCustId());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='RESP_ID_TYPE']");
			element.addAttribute("value", fm.getRespIdType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='RESP_NAME']");
			element.addAttribute("value", fm.getRespName());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='MAIL_IND']");
			element.addAttribute("value", fm.getMailInd());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='INCOME_AMT']");
			element.addAttribute("value", fm.getIncomeAmt());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_1']");
			element.addAttribute("value", fm.getFinancGoods1());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_2']");
			element.addAttribute("value", fm.getFinancGoods2());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_3']");
			element.addAttribute("value", fm.getFinancGoods3());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_4']");
			element.addAttribute("value", fm.getFinancGoods4());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_5']");
			element.addAttribute("value", fm.getFinancGoods5());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_6']");
			element.addAttribute("value", fm.getFinancGoods6());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_7']");
			element.addAttribute("value", fm.getFinancGoods7());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_8']");
			element.addAttribute("value", fm.getFinancGoods8());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_9']");
			element.addAttribute("value", fm.getFinancGoods9());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_10']");
			element.addAttribute("value", fm.getFinancGoods10());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_11']");
			element.addAttribute("value", fm.getFinancGoods11());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_12']");
			element.addAttribute("value", fm.getFinancGoods12());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_13']");
			element.addAttribute("value", fm.getFinancGoods13());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_14']");
			element.addAttribute("value", fm.getFinancGoods14());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_15']");
			element.addAttribute("value", fm.getFinancGoods15());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_16']");
			element.addAttribute("value", fm.getFinancGoods16());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_17']");
			element.addAttribute("value", fm.getFinancGoods17());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_18']");
			element.addAttribute("value", fm.getFinancGoods18());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_19']");
			element.addAttribute("value", fm.getFinancGoods19());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_20']");
			element.addAttribute("value", fm.getFinancGoods20());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_21']");
			element.addAttribute("value", fm.getFinancGoods21());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_22']");
			element.addAttribute("value", fm.getFinancGoods22());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_23']");
			element.addAttribute("value", fm.getFinancGoods23());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_24']");
			element.addAttribute("value", fm.getFinancGoods24());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_25']");
			element.addAttribute("value", fm.getFinancGoods25());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_26']");
			element.addAttribute("value", fm.getFinancGoods26());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_27']");
			element.addAttribute("value", fm.getFinancGoods27());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_28']");
			element.addAttribute("value", fm.getFinancGoods28());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_29']");
			element.addAttribute("value", fm.getFinancGoods29());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_30']");
			element.addAttribute("value", fm.getFinancGoods30());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_31']");
			element.addAttribute("value", fm.getFinancGoods31());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='FINANC_GOODS_32']");
			element.addAttribute("value", fm.getFinancGoods32());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BILL_TYPE']");
			element.addAttribute("value", fm.getBillType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BILL_CYCLE']");
			element.addAttribute("value", fm.getBillCycle());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BILL_DATE']");
			element.addAttribute("value", fm.getBillDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='LOAN_NOTIFY_TYPE']");
			element.addAttribute("value", fm.getLoanNotifyType());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SBU_BILL_DT']");
			element.addAttribute("value", fm.getSbuBillDt());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='HEAD_OFFICE']");
			element.addAttribute("value", fm.getHeadOffice());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='BANKSLIP_NONMAIL']");
			element.addAttribute("value", fm.getBankslipNonmail());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='WDMS_ID']");
			element.addAttribute("value", fm.getWdmsId());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='OPEN_AIM']");
			element.addAttribute("value", fm.getOpenAim());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='WAIVE_ADJ_CNT']");
			element.addAttribute("value", fm.getWaiveAdjCnt());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='PROM_CODE']");
			element.addAttribute("value", fm.getPromCode());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SET_STATUS']");
			element.addAttribute("value", fm.getSetStatus());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SET_STATUS_DATE']");
			element.addAttribute("value", fm.getSetStatusDate());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='COMPLX_STRUCT_FLAG']");
			element.addAttribute("value", fm.getComplxStructFlag());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='NON_REGISTER_FLAG']");
			element.addAttribute("value", fm.getNonRegisterFlag());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SWIFT_CODE']");
			element.addAttribute("value", fm.getSwiftCode());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SME_CORP_FLAG']");
			element.addAttribute("value", fm.getSmeCorpFlag());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='SET_PURPOSE']");
			element.addAttribute("value", fm.getSetPurpose());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_PRI_BUS_NATION']");
			element.addAttribute("value", fm.getAmlPriBusNation());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_BUS_NATION_RISK']");
			element.addAttribute("value", fm.getAmlBusNationRisk());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_BUS_NATION_RISK_1']");
			element.addAttribute("value", fm.getAmlBusNationRisk1());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_BUS_NATION_RISK_2']");
			element.addAttribute("value", fm.getAmlBusNationRisk2());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_BUS_NATION_RISK_3']");
			element.addAttribute("value", fm.getAmlBusNationRisk3());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_BUS_NATION_RISK_4']");
			element.addAttribute("value", fm.getAmlBusNationRisk4());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_BUS_NATION_RISK_5']");
			element.addAttribute("value", fm.getAmlBusNationRisk5());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_OVERS_FOR']");
			element.addAttribute("value", fm.getAmlOversFor());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='AML_OVERS_FOR_NATION']");
			element.addAttribute("value", fm.getAmlOversForNation());
		}

		return document;
	}
}
