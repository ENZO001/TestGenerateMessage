package com.ctbcbank.pcms.req;

import org.dom4j.Document;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import com.ctbcbank.pcms.form.Form067050;
import com.ctbcbank.pcms.htg.BaseForm;

@Service
public final class Req067050 extends ReqBase {

	@Override
	public Document fillxmlValue(Document document, BaseForm form, String sessionId) throws Exception {
		
		Element element;
		
		if (form instanceof Form067050) {
			Form067050 fm = (Form067050) form;
			
			// set session id
			element = (Element) document.selectSingleNode("hostgateway/header/data[@id='sessionId']");
			element.addAttribute("value", sessionId);

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CUST_NO']");
			element.addAttribute("value", fm.getCust_no());

			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='OPTN']");
			element.addAttribute("value", fm.getOptn());
			
			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='CUST_ID_NO']");
			element.addAttribute("value", fm.getCust_id_no());
			
			element = (Element) document.selectSingleNode("hostgateway/body/data[@id='ID_TYPE']");
			element.addAttribute("value", fm.getId_type());
		}
		return document;
	}
}
